<?php
$servername = "localhost"; //no change needed
$username = "root"; //no change needed
$password = ""; //make sure to put your database password in here or the program will not run
$database = "zooguide"; //no change needed
?>
